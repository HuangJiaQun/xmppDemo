

#import "ViewController.h"
#import "YDXMPPManager.h"

@interface ViewController ()
@property (strong, nonatomic) IBOutlet UITextField *userJid;//帐号
@property (strong, nonatomic) IBOutlet UITextField *userSecret;//密码

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//显示错误信息
- (void)showError:(NSString*)error {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提醒" message:error delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
}

//登录
- (IBAction)login:(id)sender {
    if ([self.userJid hasText] && [self.userSecret hasText]) {
    
        [YDXMPPManager loginWithUserJid:self.userJid.text password:self.userSecret.text result:^(BOOL finished, NSString *error) {
            if (finished) {
                //成功登录后，直接进入主界面
                UIStoryboard *main = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
                UIViewController *jidVC = [main instantiateViewControllerWithIdentifier:@"JidVC"];
                [self.navigationController pushViewController:jidVC animated:YES];
            } else {
                [self showError:error];//显示错误信息
            }
        }];
    }
    else
    {
        [self showError:@"帐号或密码不存在"];//显示错误信息
    }
    
    [self.userJid resignFirstResponder];
    [self.userSecret resignFirstResponder];
}

//注册
- (IBAction)register:(id)sender {
    if ([self.userJid hasText] && [self.userSecret hasText]) {
        
        [YDXMPPManager registerUserJid:self.userJid.text password:self.userSecret.text result:^(BOOL finished, NSString *error) {
            if (finished) {
                [self login:nil];//注册成功时，直接登录
            } else {
                [self showError:error];//显示错误信息
            }
        }];
    }
    else
    {
        [self showError:@"帐号或密码不存在"];//显示错误信息
    }
    
    [self.userJid resignFirstResponder];
    [self.userSecret resignFirstResponder];
}

@end
