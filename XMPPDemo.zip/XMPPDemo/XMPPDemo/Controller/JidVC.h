

#import <UIKit/UIKit.h>

@interface JidVC : UIViewController

@end
