
#import "ChatVC.h"
#import "YDXMPPManager.h"

@interface ChatVC ()
@property (strong, nonatomic) IBOutlet UITextField *message;//显示发送信息
@property (strong, nonatomic) IBOutlet UIScrollView *imageSC;//显示图片
@property (strong, nonatomic) IBOutlet UIScrollView *emjoySC;//显示qq表情
@property (strong, nonatomic) IBOutlet UIScrollView *chatMessage;//显示聊天信息

@property (nonatomic) CGFloat height; //聊天界面总高度
@property (nonatomic) int index; //当前所索
@property (nonatomic, strong) NSMutableString *qqStr;//接收qq表情的tag值

@end

@implementation ChatVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationItem.title = [NSString stringWithFormat:@"对方：%@",self.toJid];
    
    //导航项左栏目
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemReply target:self action:@selector(backAction)];
    item.tintColor = [UIColor whiteColor];
    self.navigationItem.leftBarButtonItem = item;
    
    //初始化xmpp消息处理block
    YDXMPPManager * xmppCtrl = [YDXMPPManager shareInstance];//单例对象
    xmppCtrl.msgResult = ^(id msg, XMPPType type, BOOL owned) {
        [self showMsg:msg type:type owned: owned];//显示信息到界面上
    };
    
    self.height = 10; //初始化高度
     self.qqStr = [NSMutableString string];
    
    //添加几张图片
    CGFloat width = self.imageSC.frame.size.width;
    CGFloat height = self.imageSC.frame.size.height;
    self.imageSC.contentSize = CGSizeMake(14*width, height);
    for (int i = 0; i < 14; i++) {
        UIImageView *iv = [[UIImageView alloc] initWithFrame:CGRectMake(i*width, 0, width, height)];
        iv.image = [UIImage imageNamed:[NSString stringWithFormat:@"image%d.jpg", (i+1)]];
        [self.imageSC addSubview:iv];
    }
    
    //添加几张QQ表情
    int number = 0;
    CGFloat wh = self.emjoySC.frame.size.width;
    CGFloat hh = self.emjoySC.frame.size.height;
    self.emjoySC.contentSize = CGSizeMake(9*wh, hh);
    for (int k = 0; k < 9; k++) {
        for (int i = 0; i < 4; i++) { //行
            for (int j = 0; j < 3; j++) { //列
                UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
                btn.frame = CGRectMake(k*wh+i*30+10, j*30+5, 30, 30);
                [btn setBackgroundImage:[UIImage imageNamed:[NSString stringWithFormat:@"%d", number]] forState:UIControlStateNormal];
                btn.tag = 888+number; //设置tag
                [btn addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
                [self.emjoySC addSubview:btn];
                number++;
                if (number > 104) {
                    return;
                }
            }
        }
    }
}

//返回上一层
- (void)backAction {
    [self.navigationController popViewControllerAnimated:YES];
}

//QQ表情按照点击了
- (void)buttonClicked:(UIButton*)btn {
    //重置表情图
    [self.emjoySC.subviews enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        UIView *v = (UIView*)obj;
        v.layer.borderWidth = 0;
        v.layer.borderColor =  [UIColor clearColor].CGColor;
    }];
    
    btn.layer.borderWidth = 1;
    btn.layer.borderColor = [UIColor redColor].CGColor;
    [self.qqStr appendFormat:@"%d#", (int)(btn.tag-888)];
}

//错误信息提示
- (void)showError:(NSString*)error {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提醒" message:error delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
}

#pragma mark - 发送消息
//发送消息
- (IBAction)sndMessage:(UIButton*)sender {
    
    if (self.toJid && self.toJid.length != 0) {
        if (sender.tag == 666) { //发送文本
            if ([self.message hasText]) {
                [[YDXMPPManager shareInstance] sendMessage:self.message.text userId:self.toJid msgType:XMPP_Word];
            }else {
                [self showError:@"发送文本不能为空"];
            }
            
        } else if (sender.tag == 667) { //发送图片
            UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"image%d.jpg", (self.index+1)]];
            [[YDXMPPManager shareInstance] sendMessage:image userId:self.toJid msgType:XMPP_Photo];
        } else if (sender.tag == 668) { //发送qq表情
            if (![self.qqStr isEqualToString:@""]) {
                [[YDXMPPManager shareInstance] sendMessage:self.qqStr userId:self.toJid msgType:XMPP_QQ];
            }else {
                [self showError:@"发送QQ表情不能为空"];
            }
        }
    } else {
        [self showError:@"对方帐号必须存在!"];
    }
    
    [self.message resignFirstResponder];
    [self.qqStr deleteCharactersInRange:NSMakeRange(0, self.qqStr.length)];//清空表情内容
    
    //重置表情图
    [self.emjoySC.subviews enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        UIView *v = (UIView*)obj;
        v.layer.borderWidth = 0;
        v.layer.borderColor =  [UIColor clearColor].CGColor;
    }];
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    if (scrollView == self.imageSC) {
        self.index = scrollView.contentOffset.x / scrollView.frame.size.width;
    }
}

#pragma mark - 显示信息到界面上
//显示信息到界面上
- (void)showMsg:(id)msg type:(XMPPType)type owned:(BOOL)owned{
    [self.message resignFirstResponder];
    
    int bWidth = self.chatMessage.frame.size.width*2/3;//气泡宽度
    if (type == XMPP_Word) { //文字
        
        UILabel *lab = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, bWidth, 50)];
        lab.numberOfLines = 0;
        lab.lineBreakMode = NSLineBreakByWordWrapping;
        lab.font = [UIFont systemFontOfSize:14];
        lab.text = [NSString stringWithFormat:@"%@",(NSString*)msg];
        CGSize size = [self labHeight:lab];
        
        if (owned) {//如果是自己发的信息，贴在右边；对方发的贴在左边
            lab.textColor = [UIColor greenColor];
            lab.textAlignment = NSTextAlignmentRight;
            lab.frame = CGRectMake(self.chatMessage.frame.size.width-size.width-5, self.height, size.width, size.height);
        } else {
            lab.textColor = [UIColor purpleColor];
            lab.textAlignment = NSTextAlignmentLeft;
            lab.frame = CGRectMake(5, self.height, size.width, size.height);
        }
        
        [self.chatMessage addSubview:lab];
        self.height += (size.height+10);
        
    } else if (type == XMPP_Photo) { //图片
        
        UIImageView *imgView = [[UIImageView alloc] initWithImage:(UIImage*)msg];
        imgView.backgroundColor = [UIColor whiteColor];
        imgView.layer.cornerRadius = 5;
        imgView.layer.masksToBounds = YES;
        
        int x = 5;
        if (owned) {//如果是自己发的信息，贴在右边；对方发的贴在左边
            x = self.chatMessage.frame.size.width-bWidth-5;
        }
        imgView.frame = CGRectMake(x, self.height, bWidth, bWidth);
        [self.chatMessage addSubview:imgView];
        self.height += (bWidth+10);
        
    } else if (type == XMPP_QQ) { //qq表情
        
        UIImageView *imgView = [[UIImageView alloc] initWithFrame: CGRectMake(0, self.height, bWidth, bWidth)];
        imgView.backgroundColor = [UIColor whiteColor];
        [self.chatMessage addSubview:imgView];
        
        NSMutableString *ss = [NSMutableString stringWithString:(NSString*)msg];
        if ([ss characterAtIndex:ss.length-1] == '#') {
            [ss deleteCharactersInRange:NSMakeRange(ss.length-1, 1)];
        }
        NSArray *qqs = [ss componentsSeparatedByString:@"#"];
        int lie = bWidth/48;//列数
        int hang = (int)qqs.count/lie;//行数
        int yushu = (int)qqs.count%lie;//取余
        if (hang == 0) { //表示只有一行
            hang = 1;
        } else {//表示有多行
            if (yushu != 0) {//当余数不为0时，行数需加1
                hang += 1;
            }
        }
        
        int num = 0;//数组索引
        for (int i = 0; i < hang; i++) {
            for (int j = 0; j < lie; j++) {
                UIWebView *aWebView = [[UIWebView alloc] initWithFrame:CGRectMake(j*48+10, i*48, 48, 48)];
                aWebView.scalesPageToFit = NO;//设置网页不自适应
                aWebView.scrollView.scrollEnabled = NO;//设置是否滚动
                [imgView addSubview:aWebView];
                
                NSString *strContent = [NSString stringWithFormat:@"<img src=\"%@.gif\"/>", qqs[num++]];
                NSString *str = [[NSBundle mainBundle] bundlePath];
                NSURL *baseURL = [NSURL fileURLWithPath:str isDirectory:YES];
                [aWebView loadHTMLString:strContent baseURL:baseURL];
                if (num == qqs.count) break;
            }
            if (num == qqs.count) break;
        }
        
        int hh = (hang*48+10);
        
        int qqWidth = (int)(qqs.count*48);
        if (qqWidth > bWidth) {
            qqWidth = bWidth-10;
        }
        int x = 0;
        if (owned) {//如果是对方发的贴在左边
            x = self.chatMessage.frame.size.width-qqWidth;
        }
        imgView.frame = CGRectMake(x, self.height, qqWidth, hh);
        self.height += hh;
        
    } else if (type == XMPP_QQ) { //语音
        //...
    }
    
    self.chatMessage.contentSize = CGSizeMake(self.chatMessage.frame.size.width, self.height);
    
    CGRect rt = self.chatMessage.frame;
    if (self.height > rt.size.height) {
        [self.chatMessage scrollRectToVisible:CGRectMake(rt.origin.x, self.height-rt.size.height, rt.size.width, rt.size.height) animated:NO];
    }
}

//指定宽度下，求lab的高度
- (CGSize)labHeight:(UILabel*)lab {
    CGSize size = [lab.text boundingRectWithSize:CGSizeMake(lab.bounds.size.width, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading attributes:@{NSFontAttributeName:lab.font} context:nil].size;
    return size;
}

@end
