
#import <UIKit/UIKit.h>

@interface ChatVC : UIViewController

@property (nonatomic, strong) NSString *toJid; //对方帐号

@end
