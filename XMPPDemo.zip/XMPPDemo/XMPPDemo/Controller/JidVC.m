
#import "JidVC.h"
#import "ChatVC.h"
#import "YDXMPPManager.h"

@interface JidVC ()

@property (strong, nonatomic) IBOutlet UITextField *toJid; //对方帐号

@end

@implementation JidVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    YDXMPPManager * xmppCtrl = [YDXMPPManager shareInstance];//单例对象
    self.navigationItem.title = [NSString stringWithFormat:@"自己：%@",xmppCtrl.userJid];
    
    //导航项左栏目
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemReply target:self action:@selector(backAction)];
    item.tintColor = [UIColor whiteColor];
    self.navigationItem.leftBarButtonItem = item;
    
    [self.toJid becomeFirstResponder];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//返回上一层
- (void)backAction {
    [YDXMPPManager logout];//退出登录
    [self.navigationController popViewControllerAnimated:YES];
}

//场景线回调方法，用于视图之间过渡时传递信息
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    if (![self.toJid hasText]) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提醒" message:@"对方帐号必须存在!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
    }
    
    if ([segue.identifier isEqualToString:@"yidahulian"]) {
        ChatVC *vc = (ChatVC*)segue.destinationViewController;
        vc.toJid = self.toJid.text;
    }
}

@end
