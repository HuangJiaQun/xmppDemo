

#import <Foundation/Foundation.h>
#import "XMPP.h"
#import "XMPPReconnect.h"

//配置服务器地址与通信端口号
#define XMPP_PORT 5222               //服务器端口
#define XMPP_HOST @"112.74.108.147"   //服务器地址


//枚举消息类型
typedef enum {
    XMPP_Word=0,   //文本
    XMPP_Photo,    //图片
    XMPP_Voice,    //语音
    XMPP_QQ,       //qq表情 
}XMPPType;

//声明注册及登录消息处理block(参数1表示消息结果，参数2表示错误信息)
typedef void(^XMPPResult)(BOOL finished, NSString *error);

//声明消息处理block(参数1表示消息内容，参数2表示消息类型，参数3表示是否是自己发的，YES是自己发的,NO是对方发的)
typedef void(^XMPPMsgResult)(id msg, XMPPType type, BOOL owned);


@interface YDXMPPManager : NSObject<XMPPStreamDelegate, XMPPReconnectDelegate>

@property (nonatomic, retain) NSString * userJid; //用户名
@property (nonatomic, retain) NSString * password; //密码
@property (nonatomic, copy) XMPPResult result;
@property (nonatomic, copy) XMPPMsgResult msgResult;

+ (id)shareInstance;//XMPP单例
+ (void)registerUserJid:(NSString *)userJid password:(NSString *)password result:(XMPPResult)result;//用户注册
+ (void)loginWithUserJid:(NSString *)useJid password:(NSString *)password result:(XMPPResult)result;//用户登录
+ (void)logout;//用户登出

//发xmpp消息
//参数说明：message表示消息内容  userId表示对方jid  msgType表示消息类型
- (void)sendMessage:(id)message userId:(NSString *)userId msgType:(XMPPType)type;

- (BOOL)connect;//连接服务器
- (void)connectAfterDelay:(NSTimeInterval)delay;//延时启动连接
- (void)disconnect;//断开连接
- (BOOL)isConnecting;//是否连接着

@end
