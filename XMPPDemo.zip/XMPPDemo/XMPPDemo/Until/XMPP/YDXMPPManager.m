

#import "YDXMPPManager.h"
#import <UIKit/UIDevice.h>

#import "ViewController.h"

@interface YDXMPPManager()

@property (nonatomic, strong) XMPPStream    *xmppStream;//XMPP对象
@property (nonatomic, strong) XMPPReconnect *xmppReconnect;//断线检测重连对象
@property (nonatomic) BOOL isRegister;//是否是注册

@end

@implementation YDXMPPManager

//XMPP单例
+ (id)shareInstance {
    static dispatch_once_t once;
    static YDXMPPManager * _self;
    dispatch_once( &once, ^{ _self = [[YDXMPPManager alloc] init]; } );//线程只执行一次
    return _self;
}

//初始化
- (id)init{
    if (self = [super init]) {
        //初始化XMPP对象
        self.xmppStream = [XMPPStream new];
        [self.xmppStream addDelegate:self delegateQueue:dispatch_get_main_queue()];
        [self.xmppStream setEnableBackgroundingOnSocket:YES];//保持后台连接(仅支持真机),默认是NO
    
        //接入断线检测重连模块
        self.xmppReconnect = [XMPPReconnect new];
        [self.xmppReconnect activate:self.xmppStream];
        [self.xmppReconnect addDelegate:self delegateQueue:dispatch_get_main_queue()];
    }
    return self;
}

//用户注册
+ (void)registerUserJid:(NSString *)userJid password:(NSString *)password result:(XMPPResult)result {
    YDXMPPManager * xmppCtrl = [YDXMPPManager shareInstance];//单例对象
    xmppCtrl.isRegister = YES;///当前是注册
    xmppCtrl.userJid = userJid;//设置用户帐号
    xmppCtrl.password = password;//设置密码
    xmppCtrl.result = result;
    
    [xmppCtrl disconnect];//先断开连接
    [xmppCtrl connectAfterDelay:1]; //延时启动连接
}

//用户登录
+ (void)loginWithUserJid:(NSString *)useJid password:(NSString *)password result:(XMPPResult)result {
    YDXMPPManager * xmppCtrl = [YDXMPPManager shareInstance];//单例对象
    xmppCtrl.isRegister = NO;//当前是登录
    xmppCtrl.userJid = useJid;//设置用户名帐号
    xmppCtrl.password = password;//设置密码
    xmppCtrl.result = result;
    
    [xmppCtrl disconnect];//断开连接
    [xmppCtrl connectAfterDelay:1]; //延时1s启动连接
}

//用户登出
+ (void)logout {
    YDXMPPManager *xmppCtrl = [YDXMPPManager shareInstance];//单例对象
    [xmppCtrl disconnect];//先断开连接
}

////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark - 获取消息唯一标识 | 汉字转拼音
////////////////////////////////////////////////////////////////////////////////////////////////////

//创建消息id, 唯一标识一条消息
+ (NSString *)messageUUID {
    CFUUIDRef uuidObj = CFUUIDCreate(nil);
    CFStringRef uuidString = CFUUIDCreateString(nil, uuidObj);
    NSString *result = (NSString *)CFBridgingRelease(CFStringCreateCopy( NULL, uuidString));
    CFRelease(uuidObj);
    CFRelease(uuidString);
    return result;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark - connect/disconnect
////////////////////////////////////////////////////////////////////////////////////////////////////

//连接服务器
- (BOOL)connect {
    if (!self.userJid || self.userJid.length==0 || !self.password || self.password.length==0) {
        [self disconnect];//断开连接
        return NO;
    }
    
    //如果已经连接则不重复连接
    if ([self isConnecting]) {
        return YES;
    }
    
    //组装附加信息
    NSString *deviceModel = [[UIDevice currentDevice].model stringByReplacingOccurrencesOfString:@" " withString:@""];//设备类型
    NSString *deviceUUID = [[UIDevice currentDevice].identifierForVendor UUIDString];//设备uuid
    NSString *resource = [NSString stringWithFormat:@"%@#%@", deviceModel, deviceUUID];
    
    //配置连接信息
    self.xmppStream.hostName = XMPP_HOST;
    self.xmppStream.myJID = [XMPPJID jidWithUser:self.userJid domain:XMPP_HOST resource:resource];
    self.xmppStream.hostPort = XMPP_PORT;
    
    NSError *error = nil;
    NSLog(@"XMPP > 用户%@连接服务器", self.xmppStream.myJID);
    if (![self.xmppStream connectWithTimeout:30 error:&error]) {
        NSLog(@"XMPP > 连接错误: %@", error);
        self.result(NO, @"连接服务器失败");
        return NO;
    }
    
    return YES;
}

//断开连接
- (void)disconnect {
    [self goOffline];
    [self.xmppStream disconnect];
}

//延时启动连接
- (void)connectAfterDelay:(NSTimeInterval)delay {
    [self performSelector:@selector(connect) withObject:nil afterDelay:delay];
}

//是否连接着
- (BOOL)isConnecting {
    return [self.xmppStream isConnected];
}

////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark - 发送消息
////////////////////////////////////////////////////////////////////////////////////////////////////

//发xmpp消息
//参数说明：message表示消息内容  userId表示对方jid  msgType表示消息类型
- (void)sendMessage:(id)message userId:(NSString *)userId msgType:(XMPPType)type {
    
    NSString *fromJid = [NSString stringWithFormat:@"%@@%@", self.userJid, XMPP_HOST];//自己
    NSString *toJid = [NSString stringWithFormat:@"%@@%@", userId, XMPP_HOST];//对方
    NSString *msg = nil;
    switch (type) {
        case XMPP_Word:
            msg = (NSString*)message;
            break;
        case XMPP_Photo:
            msg = [YiDaPhoto image2String:(UIImage*)message];
            break;
        case XMPP_QQ:
            msg = (NSString*)message;
            break;
        case XMPP_Voice:
            //...
            break;
            
        default:
            break;
    }
    
    if(msg && [msg length] && toJid) {
        NSXMLElement *body = [NSXMLElement elementWithName:@"body"];
        [body setStringValue:msg];//设置消息内容
        
        NSXMLElement *msgEL = [NSXMLElement elementWithName:@"message"];
        [msgEL addChild:body];//添加消息体
        
        [msgEL addAttributeWithName:@"id" stringValue:[YDXMPPManager messageUUID]];//设置消息id
        [msgEL addAttributeWithName:@"to" stringValue:toJid];//设置接收人jid
        [msgEL addAttributeWithName:@"from" stringValue:fromJid];//设置发送人jid
        [msgEL addAttributeWithName:@"msgType" stringValue:[NSString stringWithFormat:@"%d",type]];//设置消息类型

        //设置发送时间
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"yyyy年MM月dd日 HH:mm:ss"];
        NSString *timer = [formatter stringFromDate:[NSDate date]];
        [msgEL addAttributeWithName:@"date" stringValue:timer];
        
        //添加自定义字段
        //[msgEL addAttributeWithName:@"hello" stringValue:@"yidahulian"];
        
        [self.xmppStream sendElement:msgEL];//发送消息
        
        self.msgResult(message, type, YES);//返回自己发的信息
    }
}

//设置消息处理block
- (void)setMsgResult:(XMPPMsgResult)msgResult {
    _msgResult = msgResult;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark - 上线/下线
////////////////////////////////////////////////////////////////////////////////////////////////////

//上线
- (void)goOnline {
    XMPPPresence *presence = [XMPPPresence presence]; //默认是上线"available"
    [self.xmppStream sendElement:presence];
}

//下线
- (void)goOffline {
    XMPPPresence *presence = [XMPPPresence presenceWithType:@"unavailable"];//下线
    [self.xmppStream sendElement:presence];
}


////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark - XMPPStreamDelegate
////////////////////////////////////////////////////////////////////////////////////////////////////

//xmpp建立连接失败时调用
- (void)xmppStreamDidDisconnect:(XMPPStream *)sender withError:(NSError *)error {
    NSLog(@"XMPP > 用户 %@ 连接服务器 %@ 失败", self.userJid, sender.hostName);
    //self.result(NO, @"连接服务器失败");
}
//xmpp已经建立连接时调用
- (void)xmppStreamDidConnect:(XMPPStream *)sender{
    NSLog(@"XMPP > 已经和服务器建立好连接");
    
    if (self.isRegister) { //注册
        [sender registerWithPassword:self.password error:nil];//使用密码注册用户
        self.isRegister = NO;
    } else { //登陆
        NSLog(@"XMPP > 用户 %@ 正在使用密码 %@ 验证用户", self.userJid, self.password);
        [sender authenticateWithPassword:self.password error:nil];//使用密码验证用户
    }
}

//xmpp注册成功时调用
- (void)xmppStreamDidRegister:(XMPPStream *)sender {
    NSLog(@"该用户注册成功: %@", sender);
    self.result(YES, @"注册成功");
}
//xmpp注册失败时调用
- (void)xmppStream:(XMPPStream *)sender didNotRegister:(DDXMLElement *)error {
    NSLog(@"该用户注册失败: %@", error);
    self.result(NO, @"注册失败");
}

//xmpp验证用户成功时调用
- (void)xmppStreamDidAuthenticate:(XMPPStream *)sender {
    NSLog(@"XMPP > 用户验证成功登录");
    [self goOnline];//设置为在线状态
    self.result(YES, @"登录成功");
}
//xmpp验证用户失败时调用
- (void)xmppStream:(XMPPStream *)sender didNotAuthenticate:(DDXMLElement *)error {
    NSLog(@"XMPP > 用户验证失败 %@",error);
    self.result(NO, @"登录失败");
}


//xmpp已经成功发送消息 (要处理发送成功后的业务可以在此处理)
- (void)xmppStream:(XMPPStream *)sender didSendMessage:(XMPPMessage *)message {
    NSLog(@"消息已经发送");
}
//xmpp已经成功收到消息
- (void)xmppStream:(XMPPStream *)sender didReceiveMessage:(XMPPMessage *)message {
    NSLog(@"已经收到消息");
    
    //NSString *toUser = [message toStr];//接收者id
    //NSString *fromUser = [message fromStr];//发送者id
    //NSString *msgID = [message elementID];//消息id
    NSString *content = [message body];//消息内容
    int msgType = [[[message attributeForName:@"msgType"] stringValue] intValue];//消息类型
    //NSString *msgDate = [[message attributeForName:@"date"] stringValue];//消息时间
    //NSString *yida = [[message attributeForName:@"hello"] stringValue];//获取自定义字段
  
    id msg = nil;
    switch (msgType) {
        case XMPP_Word:
            msg = (NSString*)content;
            break;
        case XMPP_Photo:
            msg = (UIImage*)[YiDaPhoto string2Image:content];
            break;
        case XMPP_QQ:
            msg = (NSString*)content;
            break;
        case XMPP_Voice:
            
            break;
            
        default:
            break;
    }
    
    self.msgResult(msg, msgType, NO); //返回对方发的信息
}

////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark - XMPPReconnectDelegate
////////////////////////////////////////////////////////////////////////////////////////////////////
- (void)xmppReconnect:(XMPPReconnect *)sender didDetectAccidentalDisconnect:(SCNetworkConnectionFlags)connectionFlags {
    NSLog(@"XMPP > !!检测到意外断开连接!! > %d",connectionFlags);
}

//是否尝试自动重新连接，返回YES 则开始自动连接
- (BOOL)xmppReconnect:(XMPPReconnect *)sender shouldAttemptAutoReconnect:(SCNetworkConnectionFlags)connectionFlags {
    NSLog(@"XMPP > !!开始自动重新连接!! >: %d",connectionFlags);
    return YES;
}

@end
