//
//  YiDaPhoto.h
//  XMPPChat
//
//  Created by Mr Qian on 15/6/13.
//  Copyright (c) 2015年 Mr Qian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YiDaPhoto : NSObject
/**
 @功能：缩放图片
 @参数：图片对象  缩放的宽   缩放的高
 @返回值：缩放后的图片对象
 */
+(UIImage *)scaleImage:(UIImage *)image toWidth:(int)toWidth toHeight:(int)toHeight;

/*
 @功能：图片转换为字符串
 */
+(NSString *) image2String:(UIImage *)image;

/*
 @功能：字符串转换为图片
 */
+(UIImage *) string2Image:(NSString *)string;

@end
