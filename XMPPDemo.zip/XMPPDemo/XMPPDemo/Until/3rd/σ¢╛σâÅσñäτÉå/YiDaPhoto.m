//
//  YiDaPhoto.m
//  XMPPChat
//
//  Created by Mr Qian on 15/6/13.
//  Copyright (c) 2015年 Mr Qian. All rights reserved.
//

#import "YiDaPhoto.h"
#import "NSData+Base64.h"

@implementation YiDaPhoto

+(NSString *) image2String:(UIImage *)image{
    if (!image){//如果没有图则不操作
        return @"";
    }
    //缩放成原图的1/3
    UIImage *img = [YiDaPhoto scaleImage:image toWidth:image.size.width/2 toHeight:image.size.height/2];
    NSData *pictureData = UIImageJPEGRepresentation(img,0.8);//压缩图片质量(0.0~1.0)
    NSString *pictureDataString = [pictureData base64EncodedString];
    
    return pictureDataString;
}

+(UIImage *) string2Image:(NSString *)string{
    UIImage *image = [UIImage imageWithData:[NSData dataWithBase64EncodedString:string]];
    return image;
}

+(UIImage *)scaleImage:(UIImage *)image toWidth:(int)toWidth toHeight:(int)toHeight{
    int width=0;
    int height=0;
    int x=0;
    int y=0;
    
    if (image.size.width<toWidth){
        width = toWidth;
        height = image.size.height*(toWidth/image.size.width);
        y = (height - toHeight)/2;
    }else if (image.size.height<toHeight){
        height = toHeight;
        width = image.size.width*(toHeight/image.size.height);
        x = (width - toWidth)/2;
    }else if (image.size.width>toWidth){
        width = toWidth;
        height = image.size.height*(toWidth/image.size.width);
        y = (height - toHeight)/2;
    }else if (image.size.height>toHeight){
        height = toHeight;
        width = image.size.width*(toHeight/image.size.height);
        x = (width - toWidth)/2;
    }else{
        height = toHeight;
        width = toWidth;
    }
    
    CGSize size = CGSizeMake(width, height);
    UIGraphicsBeginImageContext(size);
    [image drawInRect:CGRectMake(0, 0, size.width, size.height)];
    image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    CGSize subImageSize = CGSizeMake(toWidth, toHeight);
    CGRect subImageRect = CGRectMake(x, y, toWidth, toHeight);
    CGImageRef imageRef = image.CGImage;
    CGImageRef subImageRef = CGImageCreateWithImageInRect(imageRef, subImageRect);
    UIGraphicsBeginImageContext(subImageSize);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextDrawImage(context, subImageRect, subImageRef);
    UIImage* subImage = [UIImage imageWithCGImage:subImageRef];
    CGImageRelease(subImageRef);
    UIGraphicsEndImageContext();
    return subImage;
}

@end
